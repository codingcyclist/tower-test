from typing import Any, Dict, Optional, Type

from dlt.common.configuration import plugins as _plugins
from dlt.common.configuration.specs.pluggable_run_context import SupportsRunContext

from dlt.cli import SupportsCliCommand as _SupportsCliCommand

from dlt_plus import current as _current

current = _current


@_plugins.hookimpl(specname="plug_run_context")
def _plug_run_context_impl(
    run_dir: Optional[str], runtime_kwargs: Optional[Dict[str, Any]]
) -> SupportsRunContext:
    """Called when run new context is created"""
    from dlt.common.runtime.run_context import RunContext
    from dlt_plus.project.exceptions import ProjectRunContextNotAvailable
    from dlt_plus.project.run_context import (
        create_project_context,
        find_project_dir,
        find_pyproject_project_dir,
    )

    # use explicit dir or find one starting from cwd
    project_dir = run_dir or find_project_dir()
    if project_dir:
        runtime_kwargs = runtime_kwargs or {}
        profile = runtime_kwargs.get("profile")
        try:
            return create_project_context(project_dir, profile=profile)
        except ProjectRunContextNotAvailable:
            # if project was not found, then try via pyproject
            project_dir = find_pyproject_project_dir(project_dir)
            if project_dir:
                return create_project_context(project_dir, profile=profile)
            else:
                raise
    else:
        # no run dir - use default context
        return RunContext(run_dir=None)


@_plugins.hookimpl(specname="plug_cli")
def _plug_cli_pond() -> Type[_SupportsCliCommand]:
    from dlt_plus.pond.cli import PondCommand

    return PondCommand


@_plugins.hookimpl(specname="plug_cli")
def _plug_cli_cache() -> Type[_SupportsCliCommand]:
    from dlt_plus.pond.cli import CacheCommand

    return CacheCommand


@_plugins.hookimpl(specname="plug_cli")
def _plug_cli_project() -> Type[_SupportsCliCommand]:
    from dlt_plus.project.cli import ProjectCommand

    return ProjectCommand


@_plugins.hookimpl(specname="plug_cli")
def _plug_cli_pipeline() -> Type[_SupportsCliCommand]:
    from dlt_plus.project.cli import ProjectPipelineCommand

    return ProjectPipelineCommand


@_plugins.hookimpl(specname="plug_cli")
def _plug_cli_dataset() -> Type[_SupportsCliCommand]:
    from dlt_plus.project.cli import DatasetCommand

    return DatasetCommand
