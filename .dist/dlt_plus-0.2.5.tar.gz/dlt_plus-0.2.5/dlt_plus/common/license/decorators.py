from functools import wraps
from typing import Any

from dlt.common.typing import AnyFun

from dlt_plus.common.constants import LICENSE_PUBLIC_KEY

from .license import validate_license, discover_license


def require_license(func: AnyFun) -> AnyFun:
    @wraps(func)
    def wrapper_func(*args: Any, **kwargs: Any) -> Any:
        license = discover_license()
        validate_license(LICENSE_PUBLIC_KEY, license)
        return func(*args, **kwargs)

    return wrapper_func
