"""Licensing lib"""

import jwt
import time
from datetime import datetime
from uuid import uuid4

from typing import TypedDict, cast, Any, Literal
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
from jwt.exceptions import ExpiredSignatureError, InvalidSignatureError


class DltLicenseException(Exception):
    pass


class DltLicenseExpiredException(DltLicenseException):
    def __init__(self) -> None:
        super().__init__("Your DLT License has expired.")


class DltLicenseSignatureInvalidException(DltLicenseException):
    def __init__(self) -> None:
        super().__init__("Your DLT License has an invalid signature.")


class DltLicenseNotFoundException(DltLicenseException):
    def __init__(self) -> None:
        super().__init__(
            """

Could not find a DLT License. Please provide your license in the RUNTIME__LICENSE
environment variable, or in your local or gobal secrets.toml file:

[runtime]
license="1234"
"""
        )


class DltPrivateKeyNotFoundException(DltLicenseException):
    def __init__(self) -> None:
        super().__init__(
            """

Could not find private key for signing. Please provide the private key in
your local or gobal secrets.toml file:

[runtime]
license_private_key="1234"
"""
        )


class DltLicense(TypedDict):
    sub: str
    iat: int
    exp: int
    iss: str
    license_type: Literal["commercial", "trial"]
    jit: str


def create_license(
    private_key: str,
    days_valid: int,
    licensee_name: str,
    license_type: Literal["commercial", "trial"],
) -> str:
    """Create a new license object"""
    private_key_bytes: Any = serialization.load_pem_private_key(
        bytes(private_key, "utf-8"), password=None, backend=default_backend()
    )

    now = int(time.time())
    exp = now + (days_valid * 24 * 60 * 60)

    license: DltLicense = {
        "iat": now,
        "exp": exp,
        "sub": licensee_name,
        "iss": "dltHub Inc.",
        "license_type": license_type,
        "jit": str(uuid4()),
    }
    encoded = jwt.encode(cast(Any, license), private_key_bytes, algorithm="RS256")

    return encoded


def validate_license(public_key: str, license: str) -> DltLicense:
    """Validate a jwt with the public key and return the decoded license object"""
    if not public_key:
        raise DltLicenseSignatureInvalidException()

    try:
        return jwt.decode(license, bytes(public_key, "utf-8"), algorithms=["RS256"])  # type: ignore[no-any-return]
    except ExpiredSignatureError as e:
        raise DltLicenseExpiredException() from e
    except (ValueError, InvalidSignatureError) as e:
        raise DltLicenseSignatureInvalidException() from e


def decode_license(license: str) -> DltLicense:
    """Decode the license without verifying that the signature is valid"""
    return jwt.decode(license, options={"verify_signature": False})  # type: ignore[no-any-return]


def discover_license() -> str:
    import dlt
    from dlt.common.configuration.exceptions import ConfigFieldMissingException

    try:
        return dlt.secrets["runtime.license"]  # type: ignore[no-any-return]
    except ConfigFieldMissingException as e:
        raise DltLicenseNotFoundException from e


def discover_private_key() -> str:
    import dlt
    from dlt.common.configuration.exceptions import ConfigFieldMissingException

    try:
        return dlt.secrets["runtime.license_private_key"]  # type: ignore[no-any-return]
    except ConfigFieldMissingException as e:
        raise DltPrivateKeyNotFoundException from e


def _to_pretty_timestamp(ts: int) -> str:
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")


def prettify_license(license: str, with_license: bool = False) -> str:
    license_dict = decode_license(license)

    output = f"""
License Id: {license_dict.get("jit")}
Licensee: {license_dict["sub"]}
Issuer: {license_dict["iss"]}
License Type: {license_dict["license_type"]}
Issued: {_to_pretty_timestamp(license_dict["iat"])}
Valid Until: {_to_pretty_timestamp(license_dict["exp"])}"""
    if with_license:
        output += f"""
===
{license}===
"""

    return output
