from dlt_plus.project.run_context import ProjectRunContext, ensure_project


def project_context() -> ProjectRunContext:
    return ensure_project()
