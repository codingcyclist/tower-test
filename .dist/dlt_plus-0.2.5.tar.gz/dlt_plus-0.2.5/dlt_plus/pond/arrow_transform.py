"""Cowboy coded stand-in for proper arrow transform templating"""

from typing import Dict
import os
import duckdb

from dlt import Schema

import importlib
from dlt_plus.pond.config import PondConfig
from dlt_plus.pond.const import PROCESSED_LOAD_IDS_TABLE, ACTIVE_LOADS_ID_TABLE


FILE_NAME = "__init__.py"


# TODO: replace poor mans jinja with proper templating
# def _get_file_name(config: PondConfig) -> str:
#     return os.path.join(config["transform"]["package_name"], FILE_NAME)


def _get_template(template_name: str, vars: Dict[str, str]) -> str:
    template_path = os.path.join(os.path.dirname(__file__), "templates", template_name)

    with open(template_path, "r", encoding="utf-8") as template_file:
        template_content = template_file.read()

    for key, value in vars.items():
        template_content = template_content.replace("{{ " + key + " }}", str(value))

    return template_content


def render_t_layer(t_layer_path: str, config: PondConfig, schema: Schema) -> None:
    os.makedirs(t_layer_path, exist_ok=True)

    file_path = os.path.join(t_layer_path, FILE_NAME)
    if os.path.exists(file_path):
        raise FileExistsError(
            f"The file {file_path} already exists. Cannot overwrite existing file."
        )

    # Open the arrow_run_template.py file
    vars = {"project_name": config["name"]}
    with open(file_path, "w", encoding="utf-8") as f:
        f.write(_get_template("arrow_run_template.py", vars))

        for table_name in schema.tables.keys():
            if table_name.startswith("_"):
                continue
        f.write(_get_template("arrow_table_template.py", {"table_name": table_name}))


def run_transform(
    t_layer_path: str,
    config: PondConfig,
    dataset_name: str,
    transformed_dataset_name: str,
    connection: duckdb.DuckDBPyConnection,
) -> None:
    active_loads_id_table = f"{transformed_dataset_name}.{ACTIVE_LOADS_ID_TABLE}"
    processed_load_ids_table = f"{transformed_dataset_name}.{PROCESSED_LOAD_IDS_TABLE}"
    # 1.
    # create table of active load ids

    # If the PROCESSED_LOAD_IDS_TABLE doesn't exist, create it
    connection.execute(f"""
        CREATE TABLE IF NOT EXISTS {processed_load_ids_table} (
            load_id VARCHAR,
            inserted_at TIMESTAMP
        )
    """)

    # Create active load id table with the right schema if it does not exist
    connection.execute(f"""
        CREATE TABLE IF NOT EXISTS {active_loads_id_table} (
            load_id VARCHAR
        )
        """)

    # reset active load ids
    connection.execute(f"""TRUNCATE TABLE {active_loads_id_table}""")

    # repopulate active load ids
    connection.execute(f"""
        INSERT INTO {active_loads_id_table}
        SELECT load_id
        FROM {dataset_name}._dlt_loads
        WHERE load_id NOT IN (
            SELECT load_id
            FROM {processed_load_ids_table}
        )
        AND status = 0
    """)

    # 2.
    # run transformations
    full_path = os.path.join(t_layer_path, FILE_NAME)
    spec = importlib.util.spec_from_file_location("module.name", full_path)
    transformations = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(transformations)

    transformations.run_transform(
        config=config,
        dataset_name=dataset_name,
        transformed_dataset_name=transformed_dataset_name,
        connection=connection,
    )

    # 3.
    # Insert active load ids into processed load ids with current timestamp
    connection.execute(f"""
        INSERT INTO {transformed_dataset_name}.{PROCESSED_LOAD_IDS_TABLE} (load_id, inserted_at)
        SELECT load_id, CURRENT_TIMESTAMP
        FROM {transformed_dataset_name}.{ACTIVE_LOADS_ID_TABLE}
    """)
