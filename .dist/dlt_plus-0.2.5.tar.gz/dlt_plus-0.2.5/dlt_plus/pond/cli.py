"""Cli for the ponds"""

import os
import argparse

from dlt.common.schema.utils import to_pretty_yaml
from dlt.cli import SupportsCliCommand, echo as fmt

from dlt_plus.common.cli import add_project_opts
from dlt_plus.pond import Pond
from dlt_plus.project.pipeline_manager import EntityFactory
from dlt_plus.project.run_context import project_from_args


class PondCommand(SupportsCliCommand):
    command = "transformation"
    help_string = "Run transformations on local cache"

    def configure_parser(self, parser: argparse.ArgumentParser) -> None:
        self.parser = parser
        add_project_opts(parser)

        parser.add_argument(
            "pond_name",
            help="Name of the transformation, use '.' for the first one found in project.",
        )

        operation_parser = parser.add_subparsers(dest="operation", required=True)

        # add all ops
        operation_parser.add_parser(
            "list", help="List all transformations discovered in this directory"
        )

        operation_parser.add_parser(
            "info", help="Transformation info: locations, cache status etc."
        )

        operation_parser.add_parser(
            "run", help="Sync cache, run transformation and commit the outputs"
        )

        operation_parser.add_parser(
            "verify-inputs",
            help="Verify that cache can connect to all defined inputs and that tables "
            + "declared are available",
        )

        operation_parser.add_parser(
            "verify-outputs",
            help="Verify that the output cache dataset contains all tables declared",
        )

        operation_parser.add_parser(
            "sync-inputs", help="Sync data from inputs to input cache dataset"
        )

        operation_parser.add_parser(
            "sync-outputs", help="Sync data from output cache dataset to outputs"
        )

        # operation_parser.add_parser(
        #     "show-inputs", help="Shows input dataset in the cache"
        # )

        # operation_parser.add_parser(
        #     "show-outputs", help="Shows output dataset"
        # )

        operation_parser.add_parser(
            "transform",
            help="Run transformations on input cache dataset and write to output cache dataset",
        )

        operation_parser.add_parser("sync-state", help="Sync cache state from outputs")

        operation_parser.add_parser(
            "render-t-layer", help="Render a starting point for the t-layer"
        )

    def execute(self, args: argparse.Namespace) -> None:
        run_context = project_from_args(args)

        factory = EntityFactory(run_context.config)
        # list
        if args.operation == "list":
            # _import_ponds()
            available_ponds = list(run_context.config.ponds)
            fmt.echo(f"Available transformations: {available_ponds}")

        # individual pond ops
        pond = factory.create_transformation(args.pond_name)
        if args.operation == "run":
            pond.run()
        elif args.operation == "verify-inputs":
            pond.verify_inputs()
        elif args.operation == "verify-outputs":
            pond.verify_outputs()
        elif args.operation == "transform":
            pond.transform()
        elif args.operation == "sync-inputs":
            pond.sync_inputs()
        elif args.operation == "sync-outputs":
            pond.sync_outputs()
        elif args.operation == "sync-state":
            pond.sync_state()
        elif args.operation == "render-t-layer":
            pond.render_transformation_layer()
        elif args.operation == "info":
            fmt.echo("Engine: %s" % fmt.bold(pond.config["transform"]["engine"]))
            t_package_path = pond.transformation_layer_path
            fmt.echo("Transformation location: %s" % fmt.bold(t_package_path))
            fmt.echo("Config:")
            fmt.echo(to_pretty_yaml(pond.config))  # type: ignore[arg-type]
            if os.path.exists(t_package_path):
                pass
            else:
                fmt.warning("t-layer not yet rendered")
        # elif args.operation == "show-inputs":
        #     from dlt.cli.pipeline_command import pipeline_command
        #     pipeline = pond._get_input_pipeline(pond.config["inputs"][0])
        #     pipeline.sync_destination()
        #     pipeline_command("show", pipeline.pipeline_name, pipeline.pipelines_dir, 0)
        # elif args.operation == "show-outputs":
        #     from dlt.cli.pipeline_command import pipeline_command
        #     pipeline = pond._get_output_pipeline(pond.config["outputs"][0])
        #     pipeline.sync_destination()
        #     # os.environ["CREDENTIALS"] = pond.cache_location
        #     pipeline_command("show", pipeline.pipeline_name, pipeline.pipelines_dir, 0)


class CacheCommand(SupportsCliCommand):
    command = "cache"
    help_string = "Manage local transformation cache"

    def configure_parser(self, parser: argparse.ArgumentParser) -> None:
        self.parser = parser
        add_project_opts(parser)

        operation_parser = parser.add_subparsers(dest="operation", required=True)

        # add all ops
        operation_parser.add_parser("info", help="Shows cache info")

        operation_parser.add_parser("show", help="Connects to cache engine")

        operation_parser.add_parser("drop", help="Drop the local cache")

        operation_parser.add_parser(
            "create-persistent-secrets",
            help="Create persistent secrets on cache for remote access.",
        )

        operation_parser.add_parser(
            "clear-persistent-secrets",
            help="Clear persistent secrets from cache for remote access.",
        )

    def cache_basic_info(self, pond: Pond) -> bool:
        cache_location = pond.cache_location
        fmt.echo("Cache query engine: %s" % fmt.bold("duckdb"))
        fmt.echo("Local cache path: %s" % fmt.bold(cache_location))
        if not os.path.exists(cache_location):
            fmt.warning("Cache not yet initialized")
            return False
        return True

    def execute(self, args: argparse.Namespace) -> None:
        run_context = project_from_args(args)

        factory = EntityFactory(run_context.config)

        # individual pond ops
        pond = factory.create_transformation(".")
        if args.operation == "drop":
            pond.drop_cache()
        elif args.operation == "create-persistent-secrets":
            pond.create_persistent_secrets()
        elif args.operation == "clear-persistent-secrets":
            pond.clear_persistent_secrets()
        elif args.operation == "info":
            self.cache_basic_info(pond)
        elif args.operation == "show":
            if self.cache_basic_info(pond):
                fmt.echo("Launching duckdb console...")
                import subprocess

                subprocess.call(["duckdb", pond.cache_location])
