import os
from typing import Dict, Optional, List, Any

from typing_extensions import TypedDict
from dlt.common.validation import validate_dict
from dlt.common.schema.typing import TWriteDisposition


class PondInput(TypedDict, total=False):
    dataset_name: str
    destination: Any
    tables: Optional[Dict[str, str]]


class PondOutput(PondInput):
    write_disposition: Optional[TWriteDisposition]


class PondCache(TypedDict, total=False):
    location: str
    pipeline_name: str
    dataset_name: str
    transformed_dataset_name: str


class PondTransform(TypedDict, total=False):
    engine: str
    package_name: str
    location: Optional[str]


class PondConfig(TypedDict, total=False):
    name: str
    transform: PondTransform
    inputs: List[PondInput]
    outputs: List[PondOutput]
    cache: PondCache


def set_defaults_and_validate(config: PondConfig) -> PondConfig:
    # set some defaults
    # TODO: pond should keep the cache dir using the same mechanism as pipeline
    # it should support SupportsPipeline protocol
    cache_config: PondCache = config.setdefault("cache", {})
    cache_config.setdefault("location", ".")
    cache_config.setdefault("pipeline_name", config["name"] + "_cache")
    cache_config.setdefault("dataset_name", config["name"] + "_cache_dataset")
    cache_config.setdefault(
        "transformed_dataset_name",
        config["cache"]["dataset_name"] + "_transformed",
    )

    # always keep location as abspath.
    cache_config["location"] = os.path.abspath(os.path.join(cache_config["location"]))

    transform_config = config.setdefault("transform", {"engine": "dbt"})
    engine = config["transform"]["engine"]
    transform_config.setdefault("package_name", engine + "_" + config["name"])

    validate_dict(PondConfig, config, ".")

    return config
