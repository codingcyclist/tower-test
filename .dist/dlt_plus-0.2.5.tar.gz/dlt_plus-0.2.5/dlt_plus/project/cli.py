import os
import json
import shutil
import argparse
import contextlib

from typing import Dict, List, Optional

import dlt
from dlt.common.utils import uniq_id
from dlt.common.storages import FileStorage
from dlt.cli import SupportsCliCommand, CliCommandException, echo as fmt
from dlt.cli.pipeline_command import pipeline_command
from dlt.cli.plugins import PipelineCommand

from dlt_plus.common.cli import add_project_opts, get_existing_subparser

from .entity_factory import EntityFactory
from .exceptions import ProjectRunContextNotAvailable
from .run_context import ProjectRunContext, list_dlt_packages, project_from_args
from .config.config import Project
from .pipeline_manager import PipelineManager


class ProjectCommand(SupportsCliCommand):
    command = "project"
    help_string = "Manage dlt projects"

    def configure_parser(self, parser: argparse.ArgumentParser) -> None:
        self.parser = parser
        add_project_opts(parser)

        subparsers = parser.add_subparsers(dest="profile_command", help="Commands", required=True)

        config_parser = subparsers.add_parser("config", help="Configuration management commands")

        config_subparsers = config_parser.add_subparsers(
            dest="config_command", help="Config commands", required=True
        )

        config_subparsers.add_parser("validate", help="Validate configuration file")

        show_parser = config_subparsers.add_parser("show", help="Show configuration")
        show_parser.add_argument(
            "--format", choices=["json", "yaml"], default="yaml", help="Output format"
        )
        show_parser.add_argument(
            "--section", help="Show specific configuration section (e.g., sources, pipelines)"
        )

        clean_local_parser = subparsers.add_parser(
            "clean",
            help=(
                "Cleans local data for the selected profile. If tmp_dir is defined in project "
                "file, it gets deleted. Pipelines and transformations working dir are also deleted "
                "by default. Data in remote destinations is not affected"
            ),
        )
        clean_local_parser.add_argument(
            "--skip-data-dir",
            action="store_true",
            default=False,
            help="Do not delete pipelines and transformations working dir.",
        )
        subparsers.add_parser(
            "list",
            help=("List all projects that could be found in installed dlt packages"),
        )
        subparsers.add_parser(
            "info",
            help=("List basic project info"),
        )
        subparsers.add_parser(
            "audit",
            help=("Creates and locks resource and secrets audit for a current profile."),
        )

    def execute(self, args: argparse.Namespace) -> None:
        if args.profile_command == "list":
            self.list_projects()
        else:
            run_context = project_from_args(args)

            if args.profile_command == "clean":
                self.clean_local_data(run_context, args)
            elif args.profile_command == "audit":
                self.create_audit(run_context)
            elif args.profile_command == "info":
                self.show_info(run_context)
            elif args.profile_command == "config":
                if args.config_command == "validate":
                    success = self.validate_config(run_context.config, args.profile)
                    if not success:
                        exit(1)

                elif args.config_command == "show":
                    self.show_config(run_context.config, args.format, args.section)

    def show_info(self, run_context: ProjectRunContext) -> None:
        fmt.echo("Project name: %s" % fmt.bold(run_context.name))
        fmt.echo("Project dir: %s" % fmt.bold(run_context.run_dir))
        fmt.echo("Settings for active profile: %s" % fmt.bold(run_context.profile))
        fmt.echo("Data dir: %s" % fmt.bold(run_context.data_dir))
        fmt.echo("Temp dir: %s" % fmt.bold(run_context.config.tmp_dir))
        fmt.echo("Settings dir: %s" % fmt.bold(run_context.settings_dir))

    def list_projects(self) -> None:
        packages = list_dlt_packages()
        if len(packages) == 0:
            fmt.echo("No installed dlt packages found")
        else:
            fmt.echo("Found ", nl=False)
            fmt.echo(fmt.bold(str(len(packages))), nl=False)
            fmt.echo(" dlt package(s):")
            for package, module, line in packages:
                fmt.echo("%s (%s): " % (fmt.bold(module), fmt.bold(package)), nl=False)
                fmt.echo(line)
            fmt.echo()

    def create_audit(self, run_context: ProjectRunContext) -> None:
        import tomlkit
        import difflib

        from dlt.common import pendulum, json
        from dlt.common.schema import Schema
        from dlt.common.storages import FilesystemConfiguration
        from dlt.common.destination.reference import DestinationClientDwhConfiguration
        from dlt.cli.config_toml_writer import WritableConfigValue, write_values

        project_config = run_context.config
        factory = EntityFactory(project_config)
        # TODO: add versioning to project files

        audit_doc = tomlkit.loads(
            f"# secrets and resource audit for {project_config.name} "
            f"on {pendulum.now().isoformat()}"
        )
        # lock the secrets
        secrets_lock = tomlkit.table(False)
        audit_doc["secrets-lock"] = secrets_lock
        # lock the known resources
        resources = tomlkit.table(False)
        audit_doc["resources"] = resources

        # get the datasets and destinations they are on
        destination_datasets: Dict[str, List[str]] = {}
        for dataset_name in sorted(
            project_config.datasets
        ):  # make sure we do this deterministically
            for destination_name in project_config.resolve_dataset_destinations(dataset_name):
                datasets_ = destination_datasets.setdefault(destination_name, [])
                datasets_.append(dataset_name)
                datasets_.sort()  # deterministic

        # TODO: also write source secrets.
        # for source_name in config.sources:
        #     source_ = factory.create_source(source_name)
        #     source_._ref.spec

        for destination_name in sorted(project_config.destinations):
            destination_ = factory.create_destination(destination_name)
            # create mock credentials to avoid credentials being resolved
            init_config = destination_.spec()
            init_config.update(destination_.config_params)
            credentials = destination_.spec.credentials_type(init_config)()
            credentials.__is_resolved__ = True
            config = destination_.spec(credentials=credentials)
            try:
                # write secrets
                config = destination_.configuration(config, accept_partial=True)
                config_value = WritableConfigValue(
                    destination_.destination_name, destination_.spec, config, ("destination",)
                )
                write_values(secrets_lock, [config_value], overwrite_existing=False)  # type: ignore[arg-type]

                # write resources
                # TODO: figure our host and database if provided
                if isinstance(config, FilesystemConfiguration):
                    resources[destination_name] = {
                        "resource_type": "filesystem",
                        "type": config.protocol,
                        "location": str(config),
                    }
                elif isinstance(config, DestinationClientDwhConfiguration):
                    resources[destination_name] = {
                        "resource_type": "warehouse",
                        "type": config.destination_type,
                        "location": str(config),
                    }
                else:
                    resources[destination_name] = {
                        "resource_type": "destination",
                        "type": config.destination_type,
                        "location": str(config),
                    }
                # write access type
                if destination_name in destination_datasets:
                    for dataset_name in destination_datasets[destination_name]:
                        dataset_cfg = project_config.datasets[dataset_name]
                        schema_contract = dataset_cfg.get("contract") or "evolve"
                        schema_contract = Schema.expand_schema_contract_settings(schema_contract)
                        resources[destination_name][dataset_name] = {  # type: ignore[index]
                            "access": "rw" if schema_contract["tables"] == "evolve" else "r",
                            "schema": schema_contract,
                        }

            except Exception:
                fmt.error(f"{destination_name} cannot be audited!")
                raise CliCommandException()
        # save or compare the audit
        audit_fn = f"{run_context.profile}.audit.toml"
        audit_path = run_context.get_setting(audit_fn)
        if os.path.isfile(audit_path):
            with open(audit_path, "r", encoding="utf-8") as f:
                existing_audit = tomlkit.load(f)
            fmt.echo("Found audit for profile %s" % fmt.bold(run_context.profile), nl=False)
            fmt.echo(" in %s:" % fmt.bold(audit_path))
            # compare normalized strings
            existing_audit_str = json.dumps(existing_audit.unwrap(), sort_keys=True, pretty=True)
            new_audit_str = json.dumps(audit_doc.unwrap(), sort_keys=True, pretty=True)
            diff = difflib.unified_diff(
                existing_audit_str.splitlines(),
                new_audit_str.splitlines(),
                fromfile="Existing " + audit_fn,
                tofile="New " + audit_fn,
                lineterm="",
            )
            diff_output = "\n".join(diff)
            if diff_output:
                fmt.error("Detected changes from the last audit")
                fmt.echo(diff_output)
                raise CliCommandException(-2)
            else:
                fmt.echo("No changes detected")
        else:
            with open(audit_path, "w", encoding="utf-8") as f:
                tomlkit.dump(audit_doc, f)
            fmt.echo("Generated audit for profile %s" % fmt.bold(run_context.profile), nl=False)
            fmt.echo(" in %s:" % fmt.bold(audit_path))

    def clean_local_data(self, run_context: ProjectRunContext, args: argparse.Namespace) -> None:
        config = run_context.config
        factory = EntityFactory(config)
        for pond_name in config.ponds:
            fmt.echo(
                "Will delete local data for transformation %s" % fmt.style(pond_name, fg="green")
            )
            pond = factory.create_transformation(pond_name)
            pond.wipe()

        # delete all files in tmp folder
        if tmp_dir := config.tmp_dir:
            # show relative path to the user
            display_dir = os.path.relpath(tmp_dir, ".")
            if len(display_dir) > len(tmp_dir):
                display_dir = tmp_dir
            fmt.echo("Will delete a temporary dir %s" % fmt.style(display_dir, fg="green"))
            if os.path.exists(tmp_dir):
                shutil.rmtree(tmp_dir, onerror=FileStorage.rmtree_del_ro)
        else:
            fmt.echo(
                "tmp_dir not defined in your project file, local storages and caches not wiped out"
            )
        if not args.skip_data_dir:
            data_dir = run_context.data_dir
            fmt.echo(
                "Will delete pipeline working folders & other entities data %s"
                % fmt.style(data_dir, fg="green")
            )
            if os.path.exists(data_dir):
                shutil.rmtree(data_dir, onerror=FileStorage.rmtree_del_ro)

    def validate_config(self, config: Project, strict: bool = False) -> bool:
        try:
            required_sections = ["sources", "pipelines"]
            for section in required_sections:
                if section not in config:
                    fmt.error(f"Error: Missing required section '{section}'")
                    return False

            fmt.echo("Configuration validation successful!")
            return True

        except Exception as e:
            fmt.error(f"Error validating configuration: {str(e)}")
            return False

    def show_config(self, config: Project, format: str, section: Optional[str] = None) -> None:
        """Display configuration in the specified format."""
        if section:
            if section not in config:
                fmt.error(f"Error: Section '{section}' not found in configuration")
                return
            config_to_show = {section: dict(config[section])}
        else:
            config_to_show = dict(config)

        if format == "json":
            fmt.echo(json.dumps(config_to_show, indent=2))
        else:  # yaml
            import yaml

            fmt.echo(yaml.dump(config_to_show, default_flow_style=False))


class DatasetCommand(SupportsCliCommand):
    # TODO: move to OSS at least partially
    command = "dataset"
    help_string = "Manage datasets"

    def configure_parser(self, parser: argparse.ArgumentParser) -> None:
        # add opts to switch project / profile
        add_project_opts(parser)

        parser.add_argument("dataset_name", metavar="dataset-name", help="Dataset name")
        parser.add_argument("--destination", help="Destination name, if many allowed", default=None)
        parser.add_argument(
            "--schema", help="Limits to schema with name for multi-schema datasets", default=None
        )

        subparsers = parser.add_subparsers(dest="operation", help="Commands", required=False)
        subparsers.add_parser("list", help="List available datasets")
        subparsers.add_parser("info", help="Dataset info")
        subparsers.add_parser("drop", help="Drops the dataset and all data in it")
        subparsers.add_parser("show", help="Shows the content of dataset in Streamlit")
        # subparsers.add_parser("schemas", help="Lists all schemas in dataset")
        # subparsers.add_parser("schema", help="Reads, syncs or drops schema in a dataset")
        # subparsers.add_parser("tables", help="Lists all tables in dataset in selected schemas")
        # subparsers.add_parser("table", help="Reads, writes a table in a dataset")
        # subparsers.add_parser(
        #     "pipelines", help="Lists all pipelines known to be writing to dataset"
        # )
        # subparsers.add_parser("read", help="Reads a table from dataset and saves to parquet/json")
        # subparsers.add_parser("write", help="Writes to a table from file")

    def execute(self, args: argparse.Namespace) -> None:
        run_context = project_from_args(args)
        entities = EntityFactory(run_context.config)
        all_datasets = list(entities.project_config.datasets.keys())
        if not all_datasets:
            fmt.echo("No datasets specified")
            return
        dataset_name = all_datasets[0] if args.dataset_name == "." else args.dataset_name
        # dataset does not reach to destination when created
        dataset = entities.create_dataset(
            dataset_name, destination_name=args.destination, schema=args.schema
        )
        if args.operation == "drop":
            dataset_location = (
                f"{dataset._destination.destination_name}"
                + f"[{str(dataset._destination.configuration(None, accept_partial=True))}]"
            )
            fmt.echo("Do you want to drop the dataset %s" % fmt.bold(dataset_name), nl=False)
            fmt.echo(" on destination %s?" % fmt.bold(dataset_location))
            fmt.secho("All data in the dataset will be irreversibly deleted!", bold=True)
            if fmt.confirm("Proceed?") is True:
                with dataset._destination_client(dataset.schema) as client:
                    if not client.is_storage_initialized():
                        fmt.warning("Storage not initialized. Dataset does not yet exist.")
                    else:
                        client.drop_storage()
                        fmt.echo("Dropped")
        elif args.operation in ("list", None):
            fmt.echo("Defined datasets:")
            fmt.echo("- " + "\n- ".join(map(fmt.bold, all_datasets)))
        elif args.operation == "info":
            fmt.echo("Dataset %s" % fmt.bold(dataset_name), nl=False)
            fmt.echo(" is available on the following destinations:")
            available_destinations = run_context.config.resolve_dataset_destinations(dataset_name)
            fmt.echo("- " + "\n- ".join(available_destinations))
            fmt.echo(
                "Connecting to destination: %s" % fmt.bold(dataset._destination.destination_name)
            )
            fmt.echo("Found schema: %s " % fmt.bold(dataset.schema.name), nl=False)
            fmt.echo(" with %s tables." % fmt.bold(str(len(dataset.schema.data_table_names()))))
            fmt.echo("- " + "\n- ".join(dataset.schema.data_table_names()))
        elif args.operation == "show":
            pipeline_name = f"{dataset_name}_pipeline_{uniq_id(4)}"
            pipeline = dlt.pipeline(
                pipeline_name, destination=dataset._destination, dataset_name=dataset_name
            )
            try:
                pipeline._inject_schema(dataset.schema)
                pipeline_command("show", pipeline.pipeline_name, pipeline.pipelines_dir, 0)
            finally:
                pipeline._wipe_working_folder()

        else:
            raise NotImplementedError(f"Command {args.operation} not yet implemented")


class ProjectPipelineCommand(PipelineCommand):
    def configure_parser(self, parser: argparse.ArgumentParser) -> None:
        # add opts to switch project / profile
        add_project_opts(parser)
        super().configure_parser(parser)

        subparsers = get_existing_subparser(parser)
        run_parser = subparsers.add_parser("run", help="Run a pipeline")
        run_parser.add_argument(
            "--limit",
            type=int,
            default=None,
            help="Limits the number of extracted pages for all resources. See source.add_limit.",
        )

    def execute(self, args: argparse.Namespace) -> None:
        # if project args are explicit we require context
        run_context = None
        with contextlib.suppress(ProjectRunContextNotAvailable):
            run_context = project_from_args(args)

        if args.list_pipelines and run_context:
            if pipelines := run_context.config.get("pipelines"):
                fmt.echo(f"{len(pipelines)} pipeline(s) defined in project:")
                for name, config in pipelines.items():
                    fmt.echo(
                        "%s from %s to %s@%s"
                        % (
                            name,
                            config.get("source"),
                            config.get("dataset_name"),
                            config.get("destination"),
                        )
                    )
            else:
                fmt.echo("No pipelines defined in project")
            fmt.echo()

            try:
                super().execute(args)
            except Exception:
                fmt.echo("No pipeline dirs found in %s" % run_context.data_dir)

        elif args.operation == "run":
            # TODO: display pre-run info: does the pipeline exist? does it have pending data
            # (we skip extract otherwise)
            # are we changing destination or dataset? do we drop any data if so ask for permission.
            pipeline_manager = PipelineManager(run_context.config)
            load_info = pipeline_manager.run_pipeline(args.pipeline_name, limit=args.limit)
            # TODO: display useful info ie. how to get traces and info
            fmt.echo(load_info)
        else:
            # execute regular pipeline command
            super().execute(args)
