import os
from typing import Any, ClassVar, Dict, Iterable, List, Mapping, Optional, cast

import dlt
from dlt.common.configuration.providers import CustomLoaderDocProvider
from dlt.common.utils import exclude_keys

from dlt_plus.pond.config import PondConfig
from dlt_plus.common.constants import DEFAULT_TEMP_DIR

from ..exceptions import ConfigurationException
from .interpolation import InterpolateEnvironmentVariables
from .types import (
    SourceConfig,
    DestinationConfig,
    PipelineConfig,
    DatasetConfig,
    ProfileConfig,
    ProjectSettingsConfig,
)


def select_keys(d: Mapping[str, Any], keys: Iterable[str]) -> Dict[str, Any]:
    return {key: d[key] for key in keys if key in d}


def exclude_keys_from_nested(data: Mapping[str, Any], keys: Iterable[str]) -> Dict[str, Any]:
    return {
        nested_key: {
            key: value if not isinstance(value, Mapping) else exclude_keys(value, keys)
            for key, value in nested_mapping.items()
        }
        for nested_key, nested_mapping in data.items()
    }


class Project(Dict[str, Any]):
    DEFAULT_PROVIDER_NAME: ClassVar[str] = "dlt_project"
    KEYS_TO_EXCLUDE: ClassVar[List[str]] = ["profiles", "pipelines", "project"]
    TYPE_KEY: ClassVar[str] = "type"

    _settings: ProjectSettingsConfig

    def __init__(self, config: Dict[str, Any], project_dir: str, profile_name: str):
        self._raw_config = config
        self.profile_name = profile_name
        self.project_dir = project_dir
        self._make_setting()
        # make several project settings available as vars
        self.interpolator = InterpolateEnvironmentVariables(extra_vars=dict(self.settings))

        # TODO: Consider doing a lazy interpolation
        self._interpolate()

    def _make_setting(self) -> None:
        self._settings: ProjectSettingsConfig = self._raw_config.get("project") or {}  # type: ignore[assignment]
        self._settings["project_dir"] = self.project_dir.rstrip(os.path.sep) + os.path.sep
        self._settings["tmp_dir"] = self.tmp_dir

    def _interpolate(self) -> None:
        interpolated_config = self.interpolator.interpolate(self._raw_config)
        super().__init__(interpolated_config)

    @property
    def settings(self) -> ProjectSettingsConfig:
        return self._settings

    @property
    def name(self) -> str:
        return self._settings.get("name") or os.path.basename(self.project_dir)

    @property
    def tmp_dir(self) -> str:
        # default project dir is relative to cwd
        tmp_dir = self._settings.get("tmp_dir") or os.path.abspath(DEFAULT_TEMP_DIR)
        return tmp_dir.rstrip(os.path.sep) + os.path.sep

    def provider(
        self, provider_name: Optional[str] = None, subset_keys: Optional[Iterable[str]] = None
    ) -> CustomLoaderDocProvider:
        provider_name = provider_name or self.DEFAULT_PROVIDER_NAME
        return CustomLoaderDocProvider(
            provider_name, lambda: Project._preprocess(self, subset_keys)
        )

    def register(
        self, provider_name: Optional[str] = None, subset_keys: Optional[Iterable[str]] = None
    ) -> None:
        dlt.config.register_provider(self.provider(provider_name, subset_keys))

    @classmethod
    def _preprocess(
        cls, config: Dict[str, Any], subset_keys: Iterable[str] = None
    ) -> Dict[str, Any]:
        if subset_keys:
            filtered = select_keys(config, subset_keys)
        else:
            filtered = config
        # this also clones the dictionary
        pipelines = filtered.get("pipelines")
        filtered = exclude_keys(filtered, cls.KEYS_TO_EXCLUDE)
        # rename the destination to destinations
        if "destinations" in filtered:
            filtered["destination"] = filtered.pop("destinations")
        # convert pipelines into pipelines config
        if pipelines:
            filtered.update(pipelines)
        return exclude_keys_from_nested(filtered, {cls.TYPE_KEY})

    @property
    def sources(self) -> Dict[str, SourceConfig]:
        return cast(Dict[str, SourceConfig], self.get("sources") or {})

    @property
    def destinations(self) -> Dict[str, DestinationConfig]:
        return cast(Dict[str, DestinationConfig], self.get("destinations") or {})

    @property
    def profiles(self) -> Dict[str, ProfileConfig]:
        return cast(Dict[str, ProfileConfig], self.get("profiles") or {})

    @property
    def pipelines(self) -> Dict[str, PipelineConfig]:
        return cast(Dict[str, PipelineConfig], self.get("pipelines") or {})

    @property
    def ponds(self) -> Dict[str, PondConfig]:
        return cast(Dict[str, PondConfig], self.get("ponds") or {})

    @property
    def datasets(self) -> Dict[str, DatasetConfig]:
        return cast(Dict[str, DatasetConfig], self.get("datasets") or {})

    def resolve_dataset_destinations(self, dataset_name: str) -> List[str]:
        """Infers possible destinations from the pipelines if not explicitly limited"""
        if dataset_name not in self.datasets:
            raise ConfigurationException(f"Dataset '{dataset_name}' not defined.")
        dataset_config = self.datasets[dataset_name] or {}
        available_destinations = dataset_config.get("on")
        if available_destinations is None:
            available_destinations = []
            for pipeline_config in self.pipelines.values():
                if pipeline_config:
                    if dataset_name == pipeline_config.get("dataset_name"):
                        if destination_name := pipeline_config.get("destination"):
                            available_destinations.append(destination_name)

        if not available_destinations:
            raise ConfigurationException(
                f"Destination(s) are not specified for dataset '{dataset_name}' and cannot be "
                "inferred from pipelines. Please use `on` property to define a list of destinations"
                " where dataset may be present."
            )
        return list(set(available_destinations))
