from typing import Any, List, Dict, Optional
from typing_extensions import TypedDict

from dlt.common.schema.typing import TSchemaContract

from dlt_plus.pond.config import PondInput, PondOutput, PondCache, PondTransform


SourceConfig = Dict[str, Any]
DestinationConfig = Dict[str, Any]


class ProjectSettingsConfig(TypedDict, total=False):
    """Project settings in Config"""

    name: Optional[str]
    default_profile: Optional[str]
    tmp_dir: Optional[str]
    project_dir: Optional[str]
    allow_undefined_datasets: Optional[bool]


class PipelineConfig(TypedDict, total=False):
    source: str
    destination: str
    dataset_name: str


class DatasetConfig(TypedDict, total=False):
    on: Optional[List[str]]
    contract: Optional[TSchemaContract]


class PondConfigWithOptionalName(TypedDict, total=False):
    name: Optional[str]
    transform: PondTransform
    inputs: List[PondInput]
    outputs: List[PondOutput]
    cache: PondCache


class ProjectConfigBase(TypedDict):
    project: Optional[ProjectSettingsConfig]
    sources: Optional[Dict[str, SourceConfig]]
    destinations: Optional[Dict[str, DestinationConfig]]
    pipelines: Optional[Dict[str, PipelineConfig]]
    datasets: Optional[Dict[str, DatasetConfig]]
    ponds: Optional[Dict[str, PondConfigWithOptionalName]]


class ProfileConfig(ProjectConfigBase):
    pass


class ProjectConfig(ProjectConfigBase):
    profiles: Optional[Dict[str, Optional[ProfileConfig]]]
