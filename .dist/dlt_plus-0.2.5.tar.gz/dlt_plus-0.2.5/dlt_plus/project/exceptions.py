import os

from dlt.common.configuration.exceptions import ConfigurationException as ConfigurationException
from dlt.common.configuration.specs.pluggable_run_context import SupportsRunContext
from dlt.common.runtime.exceptions import RuntimeException


class ProjectRunContextNotAvailable(RuntimeException):
    def __init__(self, project_dir: str, existing_context: SupportsRunContext):
        self.project_dir = project_dir
        self.existing_context = existing_context
        msg = (
            f"A dlt project could not be found for path {os.path.abspath(project_dir)}. "
            "A lookup for a dlt_project.yml file failed for this and any parent path. "
            "A Python project (pyproject.toml) defining Python package with dlt project was "
            "not found at this path."
        )
        super().__init__(msg)
