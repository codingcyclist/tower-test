import os
import re
import argparse
from types import ModuleType
import tomlkit
from contextlib import contextmanager
from typing import Any, Dict, Iterator, List, Optional, Tuple

from dlt.common import known_env
from dlt.common.configuration.specs.pluggable_run_context import SupportsRunContext
from dlt.common.configuration.container import Container
from dlt.common.configuration.exceptions import ContainerInjectableContextMangled
from dlt.common.configuration.specs.pluggable_run_context import PluggableRunContext
from dlt.common.configuration.providers import (
    EnvironProvider,
    ConfigTomlProvider,
)
from dlt.common.configuration.providers.provider import ConfigProvider
from dlt.common.runtime.run_context import RunContext, DOT_DLT
from dlt.reflection.script_inspector import import_pipeline_script

from dlt_plus.common.constants import DEFAULT_PROJECT_CONFIG_FILE
from dlt_plus.common.configuration.providers import ProfileSecretsTomlProvider

from .config.config import Project
from .config.config_loader import ConfigLoader
from .exceptions import ProjectRunContextNotAvailable


class ProjectRunContext(SupportsRunContext):
    def __init__(self, run_dir: Optional[str], config: Project):
        self._project_dir = run_dir
        self._config = config
        self._default_context = RunContext(run_dir=run_dir)

    @property
    def name(self) -> str:
        """Returns run dlt package name: as defined in the project yaml or the parent folder name
        if not defined"""
        return self._config.name or os.path.basename(self.run_dir)

    @property
    def global_dir(self) -> str:
        """Directory in which global settings are stored ie ~/.dlt/"""
        return self._default_context.global_dir

    @property
    def run_dir(self) -> str:
        """A folder containing dlt project file"""
        return os.environ.get(known_env.DLT_PROJECT_DIR, self._project_dir)

    @property
    def settings_dir(self) -> str:
        """Defines where the current settings (secrets and configs) are located"""
        return os.path.join(self.run_dir, DOT_DLT)

    @property
    def data_dir(self) -> str:
        """Isolates data for pipelines by packages and profiles ie. ~.dlt/dlt-pond-demo/dev/"""
        home_dir = self._default_context.data_dir
        return os.path.join(home_dir, self.name, self.profile)

    def initial_providers(self) -> List[ConfigProvider]:
        providers = [
            EnvironProvider(),
            ProfileSecretsTomlProvider(self.settings_dir, self.config.profile_name),
            ConfigTomlProvider(self.settings_dir, self.global_dir),
            self._config.provider(provider_name=self.name),
        ]
        return providers

    @property
    def runtime_kwargs(self) -> Dict[str, Any]:
        return {"profile": self.profile}

    @property
    def profile(self) -> str:
        return self._config.profile_name

    @property
    def config(self) -> Project:
        return self._config

    @property
    def project_module(self) -> ModuleType:
        """Returns a top Python module of the project (if importable)"""
        import importlib

        return importlib.import_module(os.path.basename(self.run_dir))

    def get_data_entity(self, entity: str) -> str:
        """Gets path in data_dir where `entity` (ie. `pipelines`, `repos`) are stored"""
        return os.path.join(self.data_dir, entity)

    def get_run_entity(self, entity: str) -> str:
        """Gets path in run_dir where `entity` (ie. `sources`, `destinations` etc.) are stored"""
        return os.path.join(self.run_dir, entity)

    def get_setting(self, setting_path: str) -> str:
        """Gets path in settings_dir where setting (ie. `secrets.toml`) are stored"""
        return os.path.join(self.settings_dir, setting_path)

    def switch_profile(self, new_profile: str) -> "ProjectRunContext":
        """Switches current profile and returns new run context"""
        return switch_profile(new_profile)

    def switch_context(
        self, project_dir: Optional[str], profile: str = None
    ) -> "ProjectRunContext":
        """Switches the context to `project_dir` and `profile` is provided"""
        return switch_context(project_dir, profile=profile)


def create_project_context(project_dir: str, profile: str = None) -> ProjectRunContext:
    project_dir = os.path.abspath(project_dir)
    try:
        # load project config
        config_loader = ConfigLoader.from_file(
            os.path.join(project_dir, DEFAULT_PROJECT_CONFIG_FILE)
        )
        config = config_loader.get_config(profile_name=profile)
    except FileNotFoundError:
        raise ProjectRunContextNotAvailable(project_dir, RunContext(run_dir=None))
    return ProjectRunContext(project_dir, config=config)


def switch_profile(profile: str) -> ProjectRunContext:
    """Changes active profile and reloads context"""

    ctx = Container()[PluggableRunContext].context
    if not isinstance(ctx, ProjectRunContext):
        raise ProjectRunContextNotAvailable(ctx.run_dir, ctx)
    return switch_context(None, profile=profile)


def switch_context(project_dir: Optional[str], profile: str = None) -> ProjectRunContext:
    container = Container()
    saved_context = container[PluggableRunContext].context
    providers = container[PluggableRunContext].providers
    try:
        # reload run context via plugins
        container[PluggableRunContext].reload(project_dir, dict(profile=profile))

        # return new run context
        ctx = container[PluggableRunContext].context
        if not isinstance(ctx, ProjectRunContext):
            raise ProjectRunContextNotAvailable(ctx.run_dir, ctx)
        return ctx
    except Exception:
        # restore context if switch fails
        container[PluggableRunContext].context = saved_context
        container[PluggableRunContext].providers = providers
        raise


@contextmanager
def injected_run_context(new_context: SupportsRunContext = None) -> Iterator[None]:
    container = Container()
    saved_context = container[PluggableRunContext].context
    providers = container[PluggableRunContext].providers
    if new_context:
        container[PluggableRunContext].context = new_context
        container[PluggableRunContext].reload_providers()
    try:
        yield
    finally:
        # do not allow context to be changed
        if new_context:
            existing_context = container[PluggableRunContext].context
            if existing_context != new_context:
                raise ContainerInjectableContextMangled(
                    new_context.__class__, existing_context, new_context
                )
        container[PluggableRunContext].context = saved_context
        container[PluggableRunContext].providers = providers


def import_context_from_dir(project_dir: str, profile: str = None) -> None:
    """(POC) Imports entities in a given context.
    Initial version to prove the concept of separate imports"""
    ctx = create_project_context(project_dir, profile=profile)

    with injected_run_context(ctx):
        # TODO: allow to import script from folder that are package (__init__.py) and without
        # TODO: we assume that __init__ import all sources
        import_pipeline_script(ctx.run_dir, "sources")


def import_context_from_dist(dist: str) -> None:
    """Import entities form a Python distribution `dist` which contains run context"""
    raise NotImplementedError()


# def find_module_run_dir(module_: str) -> str:
#     """Finds run context in `dist` that follows standard package layout"""
#     if dist is None:
#         # use pyproject


def find_pyproject_project_dir(dist_path: str) -> str:
    """Finds run context by inspecting pyproject.toml in distribution path `dist_path`"""
    dist_path = os.path.abspath(dist_path)

    # load pyproject or exit
    pyproject_path = os.path.join(dist_path, "pyproject.toml")
    if not os.path.isfile(pyproject_path):
        return None
    with open(pyproject_path, "r", encoding="utf-8") as f:
        pyproject_data = tomlkit.load(f)

    package_name = (pyproject_data.get("project") or {}).get("name")
    if not package_name:
        return None
    # convert the package name to a valid module directory name
    package_dir_name = re.sub(r"\W|^(?=\d)", "_", package_name.lower())
    # support two layouts
    for src_dir in [package_dir_name, os.path.join("src", package_dir_name)]:
        project_dir = os.path.join(dist_path, src_dir)
        if os.path.isfile(os.path.join(project_dir, DEFAULT_PROJECT_CONFIG_FILE)):
            return project_dir
    return None


def find_project_dir() -> str:
    """Look for run dlt project file (DEFAULT_PROJECT_CONFIG_FILE) file recursively up"""
    current_dir = os.getcwd()

    root_dir = os.path.abspath(os.sep)  # platform-independent root directory

    while True:
        if os.path.isfile(os.path.join(current_dir, DEFAULT_PROJECT_CONFIG_FILE)):
            return current_dir
        if current_dir == root_dir:
            # Reached the root directory without finding the file
            return find_pyproject_project_dir(os.getcwd())
        # Move up one directory level
        current_dir = os.path.dirname(current_dir)


def ensure_project(run_dir: str = None, profile: str = None) -> ProjectRunContext:
    # TODO: remove the context switching, just return current context
    # gets current run context, optionally switching to an alternative run_dir or profile
    from dlt.common.runtime.run_context import current

    if run_dir:
        # switch project in explicit path
        context: SupportsRunContext = switch_context(run_dir, profile)
    elif profile:
        # only switch profile
        context = switch_profile(profile)
    else:
        context = current()
    if not isinstance(context, ProjectRunContext):
        raise ProjectRunContextNotAvailable(context.run_dir, context)

    return context


def list_dlt_packages() -> List[Tuple[str, str, str]]:
    """Lists Python packages that contain modules with dlt packages.
    Returns list of tuples (package name, module name, first line of docstring)
    """
    import importlib.metadata
    from dlt.cli import echo as fmt

    packages: List[Tuple[str, str, str]] = []
    for dist in importlib.metadata.distributions():
        package_name = dist.metadata["Name"]
        entry_points = dist.entry_points
        # filter entry points under 'dlt_package'
        dlt_package_eps = [ep for ep in entry_points if ep.group == "dlt_package"]
        if dlt_package_eps:
            for ep in dlt_package_eps:
                module_name = ep.value
                try:
                    module = importlib.import_module(module_name)
                    # get the module-level docstring
                    docstring = module.__doc__ or ""
                    first_line = docstring.strip().split("\n")[0]
                    packages.append((package_name, module_name, first_line))
                except Exception as e:
                    fmt.error(f"Error processing {package_name}, module {module_name}: {e}")
    return packages


def project_from_args(args: argparse.Namespace) -> ProjectRunContext:
    if args.project and not os.path.exists(args.project):
        import importlib

        try:
            module = importlib.import_module(args.project)
            args.project = os.path.dirname(os.path.abspath(module.__file__))
        except ImportError:
            pass
    return ensure_project(args.project, profile=args.profile)
