# dlt+

dlt+ is a plugin to OSS `dlt` extending its functionality, adding new building blocks and cli commands.

There are two main extensions available here:

1. **run dlt** which introduces a dlt package format with a yaml/Python manifest file (**dlt_project.yml**) to declare dlt sources, destinations, pipelines etc. It also introduces **profiles** to easily switch across dev, staging, prod and personal configurations.
2. **data pond** which is a local duckdb-based data cache and data transformation execution engine

Our [dlt plus demo](../dlt_portable_data_lake/) is an example of a package that combines the two.

## Run dlt
1. It plugs a new run context into OSS dlt. Run context tells `dlt`
* where is the root of the package. in case of `run dlt` the root of the package is a folder containing `dlt_project.yml` manifest and `.dlt` for settings.
* where are data platform entitities (sources, destinations, transformations) etc. 
* What are the config providers.
* Where the working directories of pipelines are (`data_dir`)
2. Defines a layout of dlt package and its manifest
3. Defines a public API of each package as a Python module

### Package layout and content
Currently we experiment with a package layout which is compatible with a Python
package and may be (but not must be) distributed as such.
[Here's an example](../dlt_portable_data_lake/)
1. It contains `pyproject.toml` that is a Python manifest of the package ie. specifies the dependencies, source files and package build system.
2. It contains `dlt_project.yml` that is manifest of data platform entities: sources, destinations, datasets, pipelines, ponds etc.
3. It contains Python modules with source code and tests. We propose a strict layout of the modules (ie. sources code are in `./sources` folder etc.)

### dlt_project.yml and profiles
The manifest file declares data platform entities. [Looks here for an example](../dlt_portable_data_lake/dlt_portable_data_lake/dlt_project.yml).

Mainifest supports profiles that override the top level platform entities. The default profile name is `dev`. If you want to use dlt test helpers you must define `tests` profile as well.

On top of that
- You can include other files, both Python and yaml
- You can refer to secret values via `$VAR`

### Pipeline runner
We provide a simple runner for declared pipelines. The plan is to expose production grade runner with options similar to our existing Airflow helper (ie. various form of parallelism and backfilling).


### Config and secrets
dlt package manifest file is also a config provider. It's content is transformed, cleaned up and used to resolve dlt configurations of sources, destinations, pipelines etc. Existing providers are also supported:
1. environ provider
2. `.dlt/config.toml` provider, including the global config
3. `.dlt/<profile_name>.secrets.toml` a secrets toml provider but scoped to a particular profile. **secrets.toml** file is ignored. Per profile version is sought instead ie. `dev.secrets.toml`.


## Data pond
Please see the [README in the provided playground example](../../playground/pond/)

## Test license

For the time being you can use the following test license if you are working with the tools in this repo (full secrets toml):

```toml
[runtime]
license="eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE3MjcyNjUxNzcsImV4cCI6MTc1NzUwNTE3Nywic3ViIjoiZGx0SHViIENJIiwiaXNzIjoiZGx0SHViIEluYy4iLCJsaWNlbnNlX3R5cGUiOiJ0cmlhbCIsImppdCI6IjBlNjBlODUwLWY4ZjktNDZkNC04ZmVkLWQ4ZmY3ZGY1MzA0MiJ9.QIzI8Yo2vjIfXjfMoDHL64uO6XubyLqKLRwMGOCVn2XWrC6BvZVJc4kVBFoLyKx36wzZpqYIQ72X-jDJG-QsvL7nAQ1jis3PS3rP2XR05ulJUx9DU8-QXc122PJ8ihdmwdk14HddP-S9eLbsYpdMraDNw96LenIEwyk1MKrOk828s-2pxq2PdPQnQWoWFGWZ0U1VhKc2wSoIBnd6hIqBY51KaQ4X5uua3Al84ySddgdS2KX1052lIUpO3PEi8VSC8-u8WrOD9_r65Ww8iW3g-xCtpWX0gPXKvogiW3E3Krc0dXwKNePVd8n-g8EDZH8IUmyCZYjxV8Y6HO9WezA_6dzmjeuGcP079vbB0EpEug3Bk2KLPa_BfYNyG5TkW4bu-TEOgOTj-LCk9KLSfFjy9V7doNTma-Cux1dgC0wKXTJlfSxMUY6UXfS2jpGHaymsBEqAiqH86_1FCcoYBMNWTKabditc7Uip7cLJZRGZeIQhpZQ2m29ZcomuL5DugjO49PH6CQOYHM9rk5WcdHrCiUL6Cg32zXvmcinHqh_rk0_uybESbYnpbbolxpkbTGMUHgml3Q0_DVedZPcVtShNX7q9VCYNUcyFsKG3jG40lS6_qsgdJ_ewq_ABS8D1I9LM_50u5TidXJKGXJ7IYCrxGJg-5twIyc_BFyx0bMd6lSw==="
```

With

```sh
$ dlt-license
```

You can verify that the license was installed correctly.

## Generating a new license

If you need to generate a new license for a customer, you will need to have the private key for generating licenses in your secrets.toml:

```toml
license_private_key="""
-----BEGIN RSA PRIVATE KEY-----
MIIJKgIBAAKCAgEAyG4pCgHupCaZO8zhj9jjM36b/uyuhs5IIZ3v5G1LqyqiASge
qDIRnmkwZe76GZmER1GQk/UlZkV6aQAcyS/MAhQ/9JZgyKOAfoPpfGlpHEU/xTzV
...
MIIJKgIBAAKCAgEAyG4pCgHupCaZO8zhj9jjM36b/uyuhs5IIZ3v5G1LqyqiASge
qDIRnmkwZe76GZmER1GQk/UlZkV6aQAcyS/MAhQ/9JZgyKOAfoPpfGlpHEU/xTzV
-----END RSA PRIVATE KEY-----
"""
```

When this is set up, you can create a new license with this command:

```sh
$ dlt-license "Customer Name" 39 trial
```

where the first argument is the customer name, the second argument the days the license should be valid and the third the type of license "trial" or "commercial". The license string will be printed out to your console.
