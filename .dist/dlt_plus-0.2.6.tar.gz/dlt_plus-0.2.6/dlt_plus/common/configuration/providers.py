from dlt.common.configuration.providers.toml import (
    SettingsTomlProvider,
    SECRETS_TOML,
)


class ProfileSecretsTomlProvider(SettingsTomlProvider):
    def __init__(self, settings_dir: str, profile: str) -> None:
        """A secret toml provider loading from {profile}.secrets.toml file."""
        super().__init__(
            SECRETS_TOML,
            True,
            f"{profile}.{SECRETS_TOML}",
            settings_dir=settings_dir,
        )

    @property
    def is_writable(self) -> bool:
        return True
