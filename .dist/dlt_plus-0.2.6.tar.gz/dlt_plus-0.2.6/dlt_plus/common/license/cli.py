"""Cli for licensing"""

import typer

from typing import Optional

from dlt.cli import echo
from dlt_plus.common.constants import LICENSE_PUBLIC_KEY

from .license import (
    discover_license,
    discover_private_key,
    create_license,
    prettify_license,
    validate_license,
    DltPrivateKeyNotFoundException,
)

app = typer.Typer(add_completion=False)


# try to find the private key
private_key: Optional[str] = None
try:
    private_key = discover_private_key()
except DltPrivateKeyNotFoundException:
    pass


def print_license() -> None:
    """
    Print the found license
    """
    echo.echo("Searching dlt license in environment or secrets toml")
    license = discover_license()
    echo.echo("License found")
    validate_license(LICENSE_PUBLIC_KEY, license)
    echo.echo(prettify_license(license, with_license=False))


def issue_license(licensee_name: str, license_type: str, days_valid: int) -> None:
    """
    Issue a new license
    """
    if license_type not in ["trial", "commercial"]:
        echo.error("License type must be trial or commercial")
        exit(0)
    if not private_key:
        exit(0)
    echo.echo(f"Generating license for {licensee_name}, valid for {days_valid} days.")
    license = create_license(
        private_key=private_key,
        days_valid=days_valid,
        licensee_name=licensee_name,
        license_type=license_type,  # type: ignore
    )
    echo.echo("License generated")
    echo.echo(prettify_license(license, with_license=True))


if not private_key:
    """If there is no private key, only allow viewing of installed license"""

    @app.command(help="View the dlt+ license installed on your computer")
    def license() -> None:
        print_license()

else:

    @app.command(help="View the dlt+ license installed on your computer or issue a new one")
    def license(
        licensee_name: str = typer.Argument(None, help="Name of the licensee"),
        days_valid: int = typer.Argument(30, help="Amount of days the license will be valid"),
        license_type: str = typer.Argument(
            "trial", help="Type of license, can be trial or commercial"
        ),
    ) -> None:
        # generate license
        if licensee_name and private_key:
            issue_license(
                licensee_name=licensee_name,
                days_valid=days_valid,
                license_type=license_type,
            )
        # view installed license
        else:
            print_license()
