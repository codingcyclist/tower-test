import typer
import dlt

from dlt.cli import echo as fmt

from dlt.pipeline.exceptions import CannotRestorePipelineException
from dlt_plus.dbt_generator.render import (
    render_dbt_project,
    render_fact_table,
    render_mart,
)
from dlt_plus.dbt_generator.config import Config
# from dlt_plus.licensing.decorators import require_license

app = typer.Typer(add_completion=False)


@app.command()
# TODO: disable for now
# @require_license
def generate(
    pipeline_name: str = typer.Argument(None, help="The pipeline to create a dbt project for"),
    include_dlt_tables: bool = typer.Option(False, help="Do not render _dlt tables"),
    fact: str = typer.Option(None, help="Create a fact table for a given table"),
    force: bool = typer.Option(False, help="Force overwrite of existing files"),
    mart_table_prefix: str = typer.Option("", help="Prefix for mart tables"),
) -> None:
    fmt.echo(f"Starting dbt_generator for pipeline '{pipeline_name}'")

    try:
        pipeline = dlt.attach(pipeline_name=pipeline_name)
    except CannotRestorePipelineException:
        fmt.error("Could not attach to pipeline. Exiting...")
        exit(1)

    schema = pipeline.default_schema

    config = Config(include_dlt_tables=include_dlt_tables, fact_table=fact)
    config.update_from_pipeline(pipeline)
    config.force = force
    config.mart_table_prefix = mart_table_prefix

    fmt.echo(
        f"Found default schema with name '{schema.name}' and " + f"{len(schema.tables)} tables."
    )

    if fact:
        fmt.echo(
            f"Will create fact table {fact} for existing project for "
            + f"dataset '{pipeline.dataset_name}' "
            + f"at '{pipeline.destination.to_name(pipeline.destination)}'."
        )
        table_name = render_fact_table(config=config)
        fmt.echo(f"fact table created at {table_name}")

    else:
        fmt.echo(
            f"Will create dbt project to connect to dataset '{pipeline.dataset_name}' "
            + f"at '{pipeline.destination.to_name(pipeline.destination)}'."
        )

        package_path = render_dbt_project(config=config)
        mart_path = render_mart(config=config)

        fmt.echo(f"dbt project created at {package_path}. Mart created in {mart_path}")
