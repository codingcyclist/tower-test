from dlt_plus.common.exceptions import DltPlusException
from dlt_plus.dbt_generator.types import TableReference


class FilesExistException(DltPlusException, FileExistsError):
    def __init__(self, path: str) -> None:
        super().__init__("Item(s) at path {path} exist, use the --force flag to allow overwriting")


class InvalidTableReference(DltPlusException):
    def __init__(self, referencing_table: str, reference: TableReference, message: str) -> None:
        message_prefix = (
            f"Invalid reference for table '{referencing_table}' referencing table "
            + f"'{reference['referenced_table']}' with columns {reference['columns']} referencing "
            + f"columns {reference['referenced_columns']}: "
        )
        super().__init__(message_prefix + message)


class InvalidTableReferenceMissingReferencedTable(InvalidTableReference):
    pass


class InvalidTableReferenceMissingReferencingTable(InvalidTableReference):
    pass


class InvalidTableReferenceColumnsMismatch(InvalidTableReference):
    pass


class InvalidTableReferenceNoReferencingColumns(InvalidTableReference):
    pass


class InvalidTableReferenceMissingReferencingTableColumns(InvalidTableReference):
    pass


class InvalidTableReferenceMissingReferencedTableColumns(InvalidTableReference):
    pass


class InvalidTableReferenceIncompleteCompoundKeyReference(InvalidTableReference):
    pass
