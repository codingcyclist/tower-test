from dlt_plus.pond.pond import Pond
from dlt_plus.pond.config import PondConfig


def create_pond(config: PondConfig) -> Pond:
    return Pond(config)
