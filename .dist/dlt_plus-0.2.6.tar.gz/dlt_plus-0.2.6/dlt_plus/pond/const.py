PROCESSED_LOAD_IDS_TABLE = "dlt_processed_load_ids"
ACTIVE_LOADS_ID_TABLE = "dlt_active_load_ids"
