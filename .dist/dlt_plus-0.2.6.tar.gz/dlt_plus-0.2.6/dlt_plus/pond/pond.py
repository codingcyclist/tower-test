from typing import Dict, Any, cast

import dlt
import os
from contextlib import contextmanager

from dlt import Pipeline, Schema
from dlt.common import logger
from dlt.common.exceptions import DltException
from dlt.common.destination import Destination
from dlt.common.destination.reference import (
    SupportsReadableRelation,
)
from dlt.destinations import duckdb as duckdb_destination
from dlt.destinations.exceptions import DatabaseUndefinedRelation
from dlt.destinations.dataset import ReadableDBAPIDataset
from dlt.destinations.impl.filesystem.sql_client import FilesystemSqlClient
from dlt.destinations.impl.filesystem.filesystem import FilesystemClient

from dlt_plus.const import ALLOWED_DBT_VERSION
from dlt_plus.dbt_generator.render import Config, render_dbt_project, render_mart
from dlt_plus.pond.config import PondConfig, PondInput, PondOutput, set_defaults_and_validate
from dlt_plus.pond import arrow_transform
from dlt_plus.pond.const import PROCESSED_LOAD_IDS_TABLE


class PondException(DltException):
    pass


class Pond:
    def __init__(self, config: PondConfig) -> None:
        self.config = set_defaults_and_validate(config)

    #
    # Main flow
    #
    def run(self, drop_cache: bool = False) -> None:
        """Runs the full pond"""
        if drop_cache:
            self.drop_cache()
        self.sync_state()
        self.sync_inputs()
        self.transform()
        self.sync_outputs()

    def sync_inputs(self) -> None:
        """load data from inputs into cache"""
        self.verify_inputs()

        # collect datasets to load
        # tables_to_copy: Dict[str, SupportsReadableRelation] = {}
        for pond_input in self.config["inputs"]:
            # filesystem destination tables can be mounted as views in most cases
            with self._get_fs_sql_client_for_input(pond_input) as sql_client:
                sql_client.create_views_for_tables(self._get_tables_for_input(pond_input))

        # NOTE: the below currently will not run ever,
        # as we are just linking filesystem views for now
        # later we can also copy data into the cache
        # for in_table, out_table in pond_input["tables"].items():
        #    tables_to_copy[out_table] = input_pipeline._dataset()[in_table]

        # @dlt.source()
        # def in_source():
        #     for name, dataset in tables_to_copy.items():
        #         yield dlt.resource(
        #             dataset.iter_arrow(500),
        #             name=name,
        #             write_disposition="replace",
        #         )

        # cache_pipeline.run(in_source())

    #
    # Outputs
    #
    def sync_outputs(self) -> None:
        """Syncs the results into the warehouse"""
        self.verify_outputs()

        cache_pipeline = self._get_cache_pipeline(transformed_data=True)
        for pond_output in self.config["outputs"]:
            data: Dict[str, SupportsReadableRelation] = {}

            # add processed load ids
            pond_output["tables"][PROCESSED_LOAD_IDS_TABLE] = PROCESSED_LOAD_IDS_TABLE

            for in_table, out_table in pond_output["tables"].items():
                data[out_table] = cache_pipeline._dataset()[in_table]

            @dlt.source()
            def out_source() -> Any:
                for name, dataset in data.items():
                    yield dlt.resource(
                        dataset.iter_arrow(50000), name=name, write_disposition="append"
                    )

            output_pipeline = self._get_output_pipeline(pond_output)
            output_pipeline.run(out_source())

    def verify_outputs(self) -> None:
        """checks that we have tables for all defined output tables"""

        if len(self.config["outputs"]) != 1:
            raise PondException("Currently only one output is supported.")

        cache_pipeline = self._get_cache_pipeline(transformed_data=True)
        for pond_output in self.config["outputs"]:
            for table in pond_output["tables"].keys():
                try:
                    cache_pipeline._dataset()[table].fetchone()
                except DatabaseUndefinedRelation:
                    raise Exception(
                        f"Table {table} defined in output {pond_output['dataset_name']} does "
                        + "not exist in transformed dataset."
                    )

    def sync_state(self) -> None:
        """Loads processed load ids from the warehouse into the output dataset of the cache"""
        output_pipeline = self._get_output_pipeline(self.config["outputs"][0])
        with output_pipeline.destination_client() as client:
            if not client.is_storage_initialized():
                return

        # load states
        process_loads_relation = output_pipeline._dataset()[PROCESSED_LOAD_IDS_TABLE]
        cache_pipeline = self._get_cache_pipeline(True)
        cache_pipeline.run(
            process_loads_relation.iter_arrow(chunk_size=50000),
            table_name=PROCESSED_LOAD_IDS_TABLE,
            write_disposition="replace",
        )

    #
    # Inputs
    #
    def verify_inputs(self) -> None:
        """connect to each input and verify specified tables exist in schema"""

        if len(self.config["inputs"]) != 1:
            raise PondException("Currently only one input is supported.")

        for pond_input in self.config["inputs"]:
            input_dataset = self._get_input_dataset(pond_input)
            assert input_dataset.schema
            for table in (pond_input.get("tables") or {}).keys():
                if not input_dataset[table].columns_schema:
                    raise Exception(
                        f"Table {table} doesn't exist in the input of "
                        + f"pipeline {pond_input['dataset_name']}"
                    )

    def discover_input_schema(self) -> Schema:
        """Sync all inputs and calculate the input schema"""
        self.verify_inputs()
        schema = Schema(self.config["cache"]["pipeline_name"])
        for pond_input in self.config["inputs"]:
            input_dataset = self._get_input_dataset(pond_input)
            for in_table, out_table in self._get_tables_for_input(pond_input).items():
                schema.tables[out_table] = input_dataset.schema.tables[in_table]

        return schema

    def _get_tables_for_input(self, pond_input: PondInput) -> Dict[str, str]:
        input_dataset = self._get_input_dataset(pond_input)
        tables = pond_input.get("tables") or {}

        # no tables declared means sync all data tables
        if not tables:
            for t in input_dataset.schema.data_tables():
                tables[t["name"]] = t["name"]

        # add load id table
        tables[input_dataset.schema.loads_table_name] = input_dataset.schema.loads_table_name

        return tables

    #
    # Transformation layer
    #
    def render_transformation_layer(self, force: bool = False) -> None:
        """Renders a starting point for the t-layer"""
        schema = self.discover_input_schema()
        cache_pipeline = self._get_cache_pipeline()

        if self.config["transform"]["engine"] == "dbt":
            config = Config()
            config.base_folder = self.ponds_path
            config.render_readme_file = False
            config.render_run_script = False
            config.package_name = self.config["transform"]["package_name"]
            config.update_from_pipeline(cache_pipeline, schema)
            config.force = force
            render_dbt_project(config)
            render_mart(config)
        else:
            # TODO: render arrow project
            arrow_transform.render_t_layer(self.transformation_layer_path, self.config, schema)

    def transform(self) -> None:
        """Runs the transform step"""

        if not self.transformation_layer_exists():
            raise PondException(
                "Trying to run transform layer, but no project found. Have you created one?"
            )

        # create output dataset in cache
        with self._get_cache_pipeline(transformed_data=True).destination_client() as client:
            client.initialize_storage()

        with self.with_persistent_secrets():
            if self.config["transform"]["engine"] == "dbt":
                self._run_transform_dbt()
            elif self.config["transform"]["engine"] == "arrow":
                cache_pipeline = self._get_cache_pipeline()
                with cache_pipeline.sql_client() as client:
                    arrow_transform.run_transform(
                        self.transformation_layer_path,
                        config=self.config,
                        dataset_name=self.config["cache"]["dataset_name"],
                        transformed_dataset_name=self.config["cache"]["transformed_dataset_name"],
                        connection=client._conn,
                    )

    @property
    def transformation_layer_path(self) -> str:
        # make it abs path
        return os.path.join(self.ponds_path, self.config["transform"]["package_name"])

    @property
    def ponds_path(self) -> str:
        import dlt

        # TODO: we need this only to render and find t layer
        # create object model for transformations and remove from pond
        # like we have resource decoupled from pipeline

        explicit_path = self.config["transform"].get("location")
        if explicit_path:
            return os.path.abspath(explicit_path)
        # TODO: never take current context in pond. bind pond to context
        # init (when it is created)
        return dlt.current.run().get_run_entity("transformations")

    def _run_transform_dbt(self) -> None:
        cache_pipeline = self._get_cache_pipeline()
        venv = dlt.dbt.get_venv(cache_pipeline, dbt_version=ALLOWED_DBT_VERSION)
        dbt = dlt.dbt.package(cache_pipeline, self.transformation_layer_path, venv=venv)

        # run transformations
        dbt.run_all(
            # add any additional vars you need in dbt here
            additional_vars={},
            # change this to save your transformation results into another dataset
            destination_dataset_name=self.config["cache"]["transformed_dataset_name"],
        )

    def transformation_layer_exists(self) -> bool:
        return os.path.exists(self.transformation_layer_path)

    #
    # Cache management
    #
    def drop_cache(self) -> None:
        self.drop_cache_input_dataset()
        self.drop_cache_output_dataset()

    def drop_cache_input_dataset(self) -> None:
        try:
            p = self._get_cache_pipeline(False)
            with p.sql_client() as sql_client:
                sql_client.drop_dataset()
            logger.info(f"Dataset {p.dataset_name} deleted")
        except DatabaseUndefinedRelation:
            logger.info(f"Cache input dataset {p.dataset_name} does not exist. Nothing to do.")

    def drop_cache_output_dataset(self) -> None:
        try:
            p = self._get_cache_pipeline(True)
            with p.sql_client() as sql_client:
                sql_client.drop_dataset()
            logger.info(f"Dataset {p.dataset_name} deleted")
        except DatabaseUndefinedRelation:
            logger.info(f"Cache output dataset {p.dataset_name} does not exist. Nothing to do.")

    # manage cache secrets
    @contextmanager
    def with_persistent_secrets(self) -> Any:
        try:
            self.create_persistent_secrets()
            yield
        finally:
            self.clear_persistent_secrets()

    def secret_name_for_input(self, p: PondInput) -> str:
        return f"pond_secrets_{self.config['name']}_{p['dataset_name']}"

    def create_persistent_secrets(self) -> None:
        for pond_input in self.config["inputs"]:
            with self._get_fs_sql_client_for_input(pond_input) as sql_client:
                try:
                    sql_client.create_authentication(
                        persistent=True, secret_name=self.secret_name_for_input(pond_input)
                    )
                except Exception:
                    pass

    def clear_persistent_secrets(self) -> None:
        import duckdb

        for pond_input in self.config["inputs"]:
            with self._get_fs_sql_client_for_input(pond_input) as sql_client:
                try:
                    sql_client.drop_authentication(
                        secret_name=self.secret_name_for_input(pond_input)
                    )
                except duckdb.InvalidInputException:
                    pass

    def get_cache_input_dataset(self) -> ReadableDBAPIDataset:
        return cast(
            ReadableDBAPIDataset, self._get_cache_pipeline(transformed_data=False)._dataset()
        )

    def get_cache_output_dataset(self) -> ReadableDBAPIDataset:
        return cast(
            ReadableDBAPIDataset, self._get_cache_pipeline(transformed_data=True)._dataset()
        )

    def wipe(self) -> None:
        """Destroys all local data (cache, pipelines) of the pond"""
        p = self._get_cache_pipeline(False)
        p._wipe_working_folder()
        p = self._get_cache_pipeline(True)
        p._wipe_working_folder()
        if os.path.exists(self.cache_location):
            os.remove(self.cache_location)

    @property
    def cache_location(self) -> str:
        """Returns the cache location ie. duckdb path"""
        cache_db_name = self.config["name"] + "_cache.duckdb"
        return os.path.join(self.config["cache"]["location"], cache_db_name)

    #
    # Private helpers
    #
    def _get_cache_pipeline(self, transformed_data: bool = False) -> Pipeline:
        dataset_name = (
            self.config["cache"]["transformed_dataset_name"]
            if transformed_data
            else self.config["cache"]["dataset_name"]
        )
        # TODO: place cache location in pond working dir (same concept as pipeline working dir!)
        return dlt.pipeline(
            self.config["cache"]["pipeline_name"],
            destination=duckdb_destination(credentials=self.cache_location),
            dataset_name=dataset_name,
        )

    def _get_input_dataset(self, i: PondInput) -> ReadableDBAPIDataset:
        return cast(
            ReadableDBAPIDataset,
            dlt._dataset(i["destination"], dataset_name=i["dataset_name"]),
        )

    def _get_output_pipeline(self, o: PondOutput) -> Pipeline:
        pipeline_name = "pond_" + self.config["name"] + "_output_pipeline_" + o["dataset_name"]
        return dlt.pipeline(
            pipeline_name=pipeline_name,
            destination=o["destination"],
            dataset_name=o["dataset_name"],
        )

    def _get_fs_sql_client_for_input(self, pond_input: PondInput) -> FilesystemSqlClient:
        input_dataset = self._get_input_dataset(pond_input)
        fs_client = input_dataset._destination_client(input_dataset.schema)
        if not isinstance(fs_client, FilesystemClient):
            in_dest = pond_input["destination"]
            if isinstance(in_dest, Destination):
                in_dest = in_dest.destination_type
            raise PondException(
                "Currently only filesystem inputs are supported. "
                f"Dataset {pond_input['dataset_name']} is not a filesystem input but a "
                f"{in_dest}."
            )
        cache_pipeline = self._get_cache_pipeline()
        return FilesystemSqlClient(
            dataset_name=cache_pipeline.dataset_name,
            fs_client=fs_client,
            credentials=cache_pipeline.destination_client().config.credentials,  # type: ignore
        )
