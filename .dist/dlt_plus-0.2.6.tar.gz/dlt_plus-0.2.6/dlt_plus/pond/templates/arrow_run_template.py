# Arrow transformations for {{ project_name }}
import duckdb

from dlt_plus.pond.config import PondConfig
from dlt_plus.pond.const import ACTIVE_LOADS_ID_TABLE


def run_transform(
    config: PondConfig,
    dataset_name: str,
    transformed_dataset_name: str,
    connection: duckdb.DuckDBPyConnection,
) -> None:
    # processing chunk size
    chunksize = 500
    active_load_id_table = f"{transformed_dataset_name}.{ACTIVE_LOADS_ID_TABLE}"
