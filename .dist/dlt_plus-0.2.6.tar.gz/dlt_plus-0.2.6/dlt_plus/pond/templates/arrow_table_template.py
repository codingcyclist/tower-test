
    #
    # {{ table_name }} table
    #
    input_table = f"{dataset_name}.{{ table_name }}"
    output_table = f"{transformed_dataset_name}.{{ table_name }}"

    # Create the output table if it doesn't exist
    connection.execute(f"CREATE TABLE IF NOT EXISTS {output_table} AS SELECT * FROM {input_table} LIMIT 0")

    # move data from input to output table
    for batch in connection.execute(f"SELECT * FROM {input_table} WHERE _dlt_load_id IN (SELECT load_id FROM {active_load_id_table})").fetch_record_batch(chunksize):
        # TODO: do your transformations here
        connection.sql(f"INSERT INTO {output_table} SELECT * FROM batch")
        
