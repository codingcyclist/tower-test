import os
from typing import Any, Dict, Optional, Tuple

from dlt.common.utils import update_dict_nested, clone_dict_nested

from dlt_plus.common.constants import DEFAULT_PROJECT_CONFIG_PROFILE

from ..exceptions import ConfigurationException
from .config import Project
from . import yaml_loader


class ConfigLoader:
    def __init__(self, project_dir: str, config: Dict[str, Any]):
        self.project_dir = project_dir
        self.config = config

    def get_profile(self, profile_name: Optional[str] = None) -> Tuple[str, Dict[str, Any]]:
        # use default profile name if not in args
        default_profile_name = (self.config.get("project") or {}).get(
            "default_profile"
        ) or DEFAULT_PROJECT_CONFIG_PROFILE
        profile_name = profile_name or default_profile_name
        profiles = self.config.get("profiles") or {}
        # if no profiles are defined, the configuration belongs to default profile
        if profile_name not in profiles and profile_name != default_profile_name:
            raise ConfigurationException(
                f"Profile '{profile_name}' not found in project configuration"
            )
        profile_config = profiles.get(profile_name) or {}

        return profile_name, profile_config

    def get_config(self, profile_name: Optional[str] = None) -> Project:
        profile_name, profile_config = self.get_profile(profile_name)
        merged_config = self._deep_merge(self.config, profile_config)
        # drop profiles from merged config before interpolating vars
        merged_config.pop("profiles", None)
        project = Project(merged_config, self.project_dir, profile_name)

        # TODO: we convert transformations back into pond, change pond code later
        if "transformations" in project:
            from dlt_plus.pond.config import PondConfig

            project["ponds"] = {}
            # TODO: cache should be also a destination
            cache = project.get("cache") or {}
            txs = project.pop("transformations")
            for name, transformation in txs.items():
                pond: PondConfig = {
                    "transform": {
                        "engine": transformation.get("engine") or "dbt",
                    },
                    "inputs": transformation["inputs"],
                    "outputs": transformation["outputs"],
                }
                # copy props
                pond["cache"] = {}
                for prop in [
                    "location",
                    "pipeline_name",
                    "dataset_name",
                    "transformed_dataset_name",
                ]:
                    if prop in cache:
                        pond["cache"][prop] = cache[prop]  # type: ignore[literal-required]
                for prop in ["package_name", "location"]:
                    if prop in transformation:
                        pond["transform"][prop] = transformation[prop]  # type: ignore[literal-required]
                # resolve destinations if needed
                # TODO: allow ponds to create datasets
                # TODO: transformation may work only on one destination and multiple datasets
                #       make cache a destination
                for dataset in pond["inputs"] + pond["outputs"]:
                    if "destination" not in dataset:
                        dataset["destination"] = project.resolve_dataset_destinations(
                            dataset["dataset_name"]
                        )[0]

                project["ponds"][name] = pond

        # Validate the merged configuration
        # TODO: we must allow additional properties ie. runtime or normalizer settings
        # the right approach would be to preserve known props or ignore additional props
        # commented out because demo project does not load
        # validate_dict(ProjectConfig, merged_config, ".")

        return project

    def _deep_merge(self, target: Dict[str, Any], source: Dict[str, Any]) -> Dict[str, Any]:
        result = clone_dict_nested(target)
        return update_dict_nested(result, source)

    @classmethod
    def from_file(cls, file_path: str) -> "ConfigLoader":
        config = yaml_loader.load_file(file_path)
        return cls(os.path.split(file_path)[0], config)
