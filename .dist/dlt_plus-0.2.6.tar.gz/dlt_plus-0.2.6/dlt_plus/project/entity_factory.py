from typing import Union
import dlt

from dlt.common import logger
from dlt.common.destination import AnyDestination, Destination
from dlt.common.schema import Schema

from dlt.extract.source import AnySourceFactory
from dlt.extract.source import SourceReference

from dlt_plus.destinations.dataset import WritableDataset
from dlt_plus.pond import create_pond as _create_pond
from dlt_plus.pond.config import PondConfig
from dlt_plus.pond.pond import Pond

from .config.config import Project
from .config.types import PipelineConfig, SourceConfig
from .exceptions import ConfigurationException


class EntityFactory:
    def __init__(self, project_config: Project):
        self.project_config = project_config

    def create_source(self, source_name: str) -> AnySourceFactory:
        source_config = self._get_source_config(source_name)

        # TODO: accept DltSource instance

        # Check if source has the "type" key
        source_type = source_config.get("type")

        # For now, require "type", later we can add some shortcuts
        if not source_type:
            raise ConfigurationException(f"Source type is not defined for source '{source_name}'")

        # check if "with_args" is present
        with_args_dict = source_config.get("with_args") or {}
        # Override the default section name with the source name to make the configuration
        # compatible with the CustomLoaderDocProvider we are using in config.Config
        source_factory = SourceReference.from_reference(source_type).with_args(
            name=source_name, section=source_name, **with_args_dict
        )
        return source_factory

    def create_destination(self, destination_name: str) -> AnyDestination:
        if "destinations" in self.project_config:
            destination_config = self.project_config.destinations.get(destination_name)
            if destination_config is None:
                raise ConfigurationException(
                    f"Destination configuration is not found for '{destination_name}'"
                )
            # accept destination factory instance
            if isinstance(destination_config, Destination):
                return destination_config

            # create named destination
            if destination_type := destination_config.get("type"):
                return Destination.from_reference(
                    destination_type, destination_name=destination_name
                )
        else:
            # project does not define destinations, accept any shorthands and strings
            pass
        # if destination does not have a type, use shorthand notation
        return Destination.from_reference(destination_name)

    def create_dataset(
        self,
        dataset_name: str,
        destination_name: str = None,
        schema: Union[Schema, str, None] = None,
    ) -> WritableDataset:
        if "datasets" in self.project_config:
            available_destinations = self.project_config.resolve_dataset_destinations(dataset_name)
            if not destination_name:
                destination_name = available_destinations[0]
            elif destination_name not in available_destinations:
                raise ConfigurationException(
                    f"Dataset {dataset_name} is not available on destination {destination_name}"
                )
            return WritableDataset(
                self.project_config,
                self.project_config.datasets[dataset_name],
                destination=self.create_destination(available_destinations[0]),
                dataset_name=dataset_name,
                schema=schema,
            )
        else:
            raise ConfigurationException("No configured datasets")

    def create_transformation(self, name: str) -> Pond:
        """Get transformation by name"""
        available_ponds = list(self.project_config.ponds.keys())

        if not available_ponds:
            raise ConfigurationException("No ponds found in project.")

        if not name or name == ".":
            name = available_ponds[0]
            logger.info(f"No transformation name given, taking the first discovered: {name}")

        pond_config: PondConfig
        if pond_config := self.project_config.ponds.get(name):
            pond_config["name"] = name
            # create factories from config
            for input in pond_config.get("inputs", []):
                destination = input["destination"]
                if isinstance(destination, str):
                    input["destination"] = self.create_destination(input["destination"])
            for output in pond_config.get("outputs", []):
                destination = output["destination"]
                if isinstance(destination, str):
                    output["destination"] = self.create_destination(output["destination"])
            return _create_pond(pond_config)
        else:
            raise ConfigurationException(
                f"No transformation with name {name} found. Available ponds: {available_ponds}"
            )

    def create_pipeline(self, pipeline_name: str) -> dlt.Pipeline:
        pipeline_config = self._get_pipeline_config(pipeline_name)
        destination_name = pipeline_config.get("destination")
        if not destination_name:
            raise ConfigurationException(
                f"Destination is not defined for pipeline '{pipeline_name}'"
            )
        # verify if a valid dataset exists
        dataset_name = pipeline_config["dataset_name"]
        if dataset_name in self.project_config.datasets:
            # check if pipeline is on the list
            if destination_name not in self.project_config.resolve_dataset_destinations(
                dataset_name
            ):
                raise ConfigurationException(
                    f"Pipeline {pipeline_name} wants to load to destination {destination_name} "
                    f"but dataset {dataset_name} does not allow for that. Use 'on' list to "
                    "enable explicit destinations."
                )
        else:
            if not self.project_config.settings.get("allow_undefined_datasets"):
                raise ConfigurationException(
                    f"Pipeline {pipeline_name} need dataset {dataset_name} which is not defined "
                    "and project settings (allow_undefined_datasets) prevent undefined dataset "
                    "to be used."
                )

        pipeline_config
        return dlt.pipeline(
            pipeline_name,
            destination=self.create_destination(destination_name),
            dataset_name=dataset_name,
        )

    def _get_pipeline_config(self, pipeline_name: str) -> PipelineConfig:
        pipeline_config = self.project_config.pipelines.get(pipeline_name)

        if not pipeline_config:
            raise ConfigurationException(
                f"Pipeline '{pipeline_name}' not found in project configuration"
            )

        return pipeline_config

    def _get_source_config(self, source_name: str) -> SourceConfig:
        source_config = self.project_config.sources.get(source_name)
        if not source_config:
            raise ConfigurationException(f"Source configuration is not found for '{source_name}'")
        return source_config
